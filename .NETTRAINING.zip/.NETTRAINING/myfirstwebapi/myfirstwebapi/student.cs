﻿namespace myfirstwebapi
{
    public class student
    {
        public int rollno{ get; set;}
        public string name { get; set; }
        public int marks { get; set; }
        public int percent { get; set; }


    }
}
