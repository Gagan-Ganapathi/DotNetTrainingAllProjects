﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace myfirstwebapi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private static List<student> _students = new List<student>() {
            new student{ rollno=1,name="gg",marks=90,percent=90 },
            new student{ rollno=2,name="kk",marks=80,percent=80 },
            new student{ rollno=3,name="gg",marks=65,percent=65 },
            new student{ rollno=4,name="gg",marks=70,percent=70 }

        };

        [HttpGet]
        public ActionResult<IEnumerable<student>> getStudent()
        {
            return _students;
        }

        [HttpGet("{Rollno}")]
        public ActionResult<student> getStudent(int Rollno)
        {
           var Stu= _students.FirstOrDefault(p => p.rollno==Rollno) ;

        if (Stu == null) {
            return NotFound();
        }
        return Stu;
        }

        [HttpPost]
        public ActionResult<student> postStudent(student st)
        {
            _students.Add(st);
            return CreatedAtAction(nameof(getStudent), new {Rollno= st.rollno},st);
        }

        [HttpPut("{Rollno}")]
        public ActionResult<student> putStudent(int Rollno, student st)
        {
            if (Rollno != st.rollno)
            {
                return BadRequest();
            }

            var existingstu = _students.FirstOrDefault(p => p.rollno == Rollno);
            if (existingstu == null)
            {
                return NotFound();
            }

            existingstu.name = st.name;
            existingstu.marks = st.marks;
            existingstu.percent = st.percent;

            return NoContent();
        }

        [HttpDelete("{Rollno}")]
        public ActionResult<student> deletestudent(int Rollno)
        {
            var stu= _students.FirstOrDefault(p=>p.rollno==Rollno);
            if (stu == null){
                return NotFound();
            }
             _students.Remove(stu);
            return NoContent();
        }
    }
}
