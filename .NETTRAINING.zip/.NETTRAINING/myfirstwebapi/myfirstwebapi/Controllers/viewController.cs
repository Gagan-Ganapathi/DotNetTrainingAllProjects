﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace myfirstwebapi.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class viewController : ControllerBase
    {
        [HttpGet]
        public string get()
        {
            return "gagan";
        }

        [HttpGet]
        public string xyzget()
        {
            return "xyz";
        }
    }
}
