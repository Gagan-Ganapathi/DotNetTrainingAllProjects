import { Component } from '@angular/core';

@Component({
  selector: 'app-add-new',
  standalone: true,
  imports: [],
  templateUrl: './add-new.component.html',
  styleUrl: './add-new.component.css'
})
export class AddNewComponent {

}
