export class ListUser{
    id: number ;
    
    name:string;
    email:string;
    role:string;
    status:string;
};