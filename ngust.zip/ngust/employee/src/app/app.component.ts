import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ListemployeeComponent } from './components/listemployee/listemployee.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,ListemployeeComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'employee';
}
