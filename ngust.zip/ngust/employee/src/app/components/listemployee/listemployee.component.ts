import { Component } from '@angular/core';
import { Employee } from '../../Model/Employee';
import { DatePipe } from '@angular/common';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-listemployee',
  standalone: true,
  imports: [DatePipe,CommonModule],
  templateUrl: './listemployee.component.html',
  styleUrl: './listemployee.component.css'
})
export class ListemployeeComponent {
employees:Employee[]=[{
  id:1,
  name:"Gagan",
  gender:"male",
  email:"abc@gmail.com",
  phoneNumber:2332324242,
  contactPreference:"deeksha",
  dateOfBirth:new Date(10/12/2010),
  department:"CSE",
  isActive:true,
  photoPath:'./daali.jpg'

},{
  id:2,
  name:"Dove",
  gender:"female",
  email:"abc@gmail.com",
  phoneNumber:2332324242,
  contactPreference:"deeksha",
  dateOfBirth:new Date(2/12/2003),
  department:"CSE",
  isActive:true,
  photoPath:'./dove.jpg'

},{
  id:3,
  name:"Jalagara",
  gender:"male",
  email:"abc@gmail.com",
  phoneNumber:2332324242,
  contactPreference:"deeksha",
  dateOfBirth:new Date(),
  department:"CSE",
  isActive:true,
  photoPath:'./sisya.jpg'

}]

}
