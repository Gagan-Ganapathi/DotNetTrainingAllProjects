﻿namespace SavingsInvestment.Models.DTO
{
    public class InvestmentAlertNotification : NotificationBase
    {
    }
}
