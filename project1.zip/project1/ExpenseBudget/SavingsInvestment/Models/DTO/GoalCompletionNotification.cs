﻿namespace SavingsInvestment.Models.DTO
{
    public class GoalCompletionNotification : NotificationBase
    {
    }
}
