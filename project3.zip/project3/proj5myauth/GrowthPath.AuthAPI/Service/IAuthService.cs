﻿using AuthMicroservice.Models;
using AuthMicroservice.Models.DTO;

namespace AuthMicroservice.Service
{
    public interface IAuthService
    {
        Task<string> Register(RegistrationRequestDto registrationRequestDto);
        Task<LoginResponseDto> Login(LoginRequestDto loginRequestDto);
        Task<bool> AssignRole(string email, string rolename);
        Task<UserDto> GetUserByIdAsync(string userId);
        Task<List<UserDto>> GetAllUsersAsync(); // New method
        Task<bool> UpdateUserAsync(string userId, UserDto updatedUser);



    }
}
