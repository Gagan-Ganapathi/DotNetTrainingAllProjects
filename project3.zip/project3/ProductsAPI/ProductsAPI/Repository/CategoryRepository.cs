﻿using Microsoft.EntityFrameworkCore;
using ProductsAPI.Data;
using ProductsAPI.Models;

namespace ProductsAPI.Repository
{
    public class CategoryRepository : ICategoryRepository
    {
      

        private readonly ProductContext _dbContext;

        public CategoryRepository(ProductContext dbContext)

        {

            _dbContext = dbContext;

        }

        public void DeleteCategory(int categoryId)

        {

            var category = _dbContext.Categories.Find(categoryId);

            _dbContext.Categories.Remove(category);

            Save();

        }

        public Category GetCategoryByID(int categoryId)

        {

            return _dbContext.Categories.Find(categoryId);

        }

        public IEnumerable<Category> GetCategory()

        {

            return _dbContext.Categories.ToList();

        }

        public void InsertCategory(Category cat)

        {

            _dbContext.Add(cat);

            Save();
        }

        public void Save()

        {

            _dbContext.SaveChanges();

        }

        public void UpdateCategory(Category cat)

        {

            _dbContext.Entry(cat).State = EntityState.Modified;

            Save();

        }


    }
}
