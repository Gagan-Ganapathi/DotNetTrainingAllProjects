﻿using ProductsAPI.Models;

namespace ProductsAPI.Repository
{
    public interface ICategoryRepository
    {
        IEnumerable<Category> GetCategory();

        Category GetCategoryByID(int category);

        void InsertCategory(Category category);

        void DeleteCategory(int categoryId);

        void UpdateCategory(Category product);

        void Save();
    }
}
