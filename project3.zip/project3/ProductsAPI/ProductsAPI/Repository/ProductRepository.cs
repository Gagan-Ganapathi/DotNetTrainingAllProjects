﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProductsAPI.Data;
using ProductsAPI.Models;

namespace ProductsAPI.Repository
{
    public class ProductRepository : IProductRepository
    {
        private readonly ProductContext _dbContext;

        public ProductRepository(ProductContext dbContext)

        {

            _dbContext = dbContext;

        }

        public void DeleteProduct(int productId)

        {

            var product = _dbContext.Products.Find(productId);

            _dbContext.Products.Remove(product);

            Save();

        }

        public Product GetProductByID(int productId)

        {

            return _dbContext.Products.Find(productId);

        }

        public IEnumerable<Product> GetProducts()

        {

            return _dbContext.Products.ToList();

        }

        public void InsertProduct(Product pro)

        {

            _dbContext.Add(pro);

            Save();
        }

        public void Save()

        {

            _dbContext.SaveChanges();

        }

        public IActionResult UpdateProduct(Product product)

        {
            var pro = _dbContext.Products.FirstOrDefault(i => i.Id == product.Id);
            if (pro != null)
            {
                pro.Name = product.Name;
                pro.Price = product.Price;
                pro.Description = product.Description;
                pro.CategoryId = product.CategoryId;

                _dbContext.Entry(product).State = EntityState.Modified;
                Save();
                return Ok();

            }
            return NotFound();


        }


    }
}
