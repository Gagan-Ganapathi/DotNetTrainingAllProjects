﻿using Microsoft.AspNetCore.Mvc;
using ProductsAPI.Models;
using ProductsAPI.Repository;
using System.Transactions;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ProductsAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        private readonly ICategoryRepository _categoryRepository;

        public CategoryController(ICategoryRepository categoryRepository)

        {

            _categoryRepository = categoryRepository;

        }

        // GET: api/Product

        [HttpGet]

        public IActionResult Get()

        {

            var products = _categoryRepository.GetCategory();

            return new OkObjectResult(products);

        }

        // GET: api/Product/5

        [HttpGet("{id}", Name = "Gett")]

        public IActionResult Get(int id)

        {

            var product = _categoryRepository.GetCategoryByID(id);

            return new OkObjectResult(product);

        }

        // POST: api/Product

        [HttpPost]

        public IActionResult Post([FromBody] Category cat)

        {

            using (var scope = new TransactionScope())

            {

                _categoryRepository.InsertCategory(cat);

                scope.Complete();

                return CreatedAtAction(nameof(Get), new { id = cat.Id }, cat);

            }

        }

        // PUT: api/Product/5

       /* [HttpPut]

        public IActionResult Put([FromBody] Product product)

        {

            if (product != null)

            {

                using (var scope = new TransactionScope())

                {

                    _productRepository.UpdateProduct(product);

                    scope.Complete();

                    return new OkResult();

                }

            }

            return new NoContentResult();

        }*/

        // DELETE: api/ApiWithActions/5

        [HttpDelete("{id}")]

        public IActionResult Delete(int id)

        {

            _categoryRepository.DeleteCategory(id);

            return new OkResult();

        }
    }
}
