/*import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {

}*/
// import { Component } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { RouterLink, RouterOutlet } from '@angular/router';
// import { SidebarComponent } from '../sidebar/sidebar.component';


// @Component({
//   selector: 'app-home',
//   standalone: true,
//   imports: [CommonModule, RouterOutlet,RouterLink, SidebarComponent],
//   template: `
//     <div class="d-flex">
//       <app-sidebar></app-sidebar>
//       <!--<div class="main-content" [class.sidebar-collapsed]="sidebar.isCollapsed">-->
       
      
//     </div>
//   `,
//   styleUrls: ['./home.component.css']
// })
// export class HomeComponent {
//   title = 'finance-tracker';
// sidebar: any;
// }
