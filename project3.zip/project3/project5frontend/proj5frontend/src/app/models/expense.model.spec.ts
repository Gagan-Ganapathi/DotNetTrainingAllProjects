import { ExpenseModel } from './expense.model';

describe('ExpenseModel', () => {
  it('should create an instance', () => {
    expect(new ExpenseModel()).toBeTruthy();
  });
});
