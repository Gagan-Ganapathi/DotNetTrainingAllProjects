import { TransactionModel } from './transaction.model';

describe('TransactionModel', () => {
  it('should create an instance', () => {
    expect(new TransactionModel()).toBeTruthy();
  });
});
