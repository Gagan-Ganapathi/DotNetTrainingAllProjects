import { BudgetModel } from './budget.model';

describe('BudgetModel', () => {
  it('should create an instance', () => {
    expect(new BudgetModel()).toBeTruthy();
  });
});
