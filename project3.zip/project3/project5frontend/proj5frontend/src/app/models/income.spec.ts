import { Income } from './income.model';

describe('Income', () => {
  it('should create an instance', () => {
    expect(new Income()).toBeTruthy();
  });
});
