import { AccountModel } from './account.model';

describe('AccountModel', () => {
  it('should create an instance', () => {
    expect(new AccountModel()).toBeTruthy();
  });
});
