import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-emp',
  standalone: true,
  imports: [],
  templateUrl: './edit-emp.component.html',
  styleUrl: './edit-emp.component.css'
})
export class EditEmpComponent {

}
