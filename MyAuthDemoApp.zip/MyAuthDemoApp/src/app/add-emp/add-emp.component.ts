import { Component } from '@angular/core';

@Component({
  selector: 'app-add-emp',
  standalone: true,
  imports: [],
  templateUrl: './add-emp.component.html',
  styleUrl: './add-emp.component.css'
})
export class AddEmpComponent {

}
