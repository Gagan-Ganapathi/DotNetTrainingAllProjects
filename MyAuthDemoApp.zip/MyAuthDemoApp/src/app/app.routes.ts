import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { LayoutComponent } from './layout/layout.component';
import { AddEmpComponent } from './add-emp/add-emp.component';
import { EditEmpComponent } from './edit-emp/edit-emp.component';
import { DeleteEmpComponent } from './delete-emp/delete-emp.component';

export const routes: Routes = [
    {
        path:'',
        redirectTo:'layout',
        pathMatch:'full'
    },
    {
        path:'login',
        component:LoginComponent
    },{
        path:'layout',
        component:LayoutComponent,
        children:[
            {
                path:'add-emp',component:AddEmpComponent
            },
            {
                path:'edit-emp',component:EditEmpComponent
            },
             {
                path:'delete-emp',component:DeleteEmpComponent
            }, 
            
        ]
    }
];
