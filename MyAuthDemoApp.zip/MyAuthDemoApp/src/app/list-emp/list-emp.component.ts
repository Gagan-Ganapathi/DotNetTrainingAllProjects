import { Component } from '@angular/core';

@Component({
  selector: 'app-list-emp',
  standalone: true,
  imports: [],
  templateUrl: './list-emp.component.html',
  styleUrl: './list-emp.component.css'
})
export class ListEmpComponent {

}
