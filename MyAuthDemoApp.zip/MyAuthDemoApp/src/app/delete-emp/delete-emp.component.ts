import { Component } from '@angular/core';

@Component({
  selector: 'app-delete-emp',
  standalone: true,
  imports: [],
  templateUrl: './delete-emp.component.html',
  styleUrl: './delete-emp.component.css'
})
export class DeleteEmpComponent {

}
