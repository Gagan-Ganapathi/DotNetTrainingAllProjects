import { Component } from '@angular/core';

@Component({
  selector: 'app-show-emp-by-id',
  standalone: true,
  imports: [],
  templateUrl: './show-emp-by-id.component.html',
  styleUrl: './show-emp-by-id.component.css'
})
export class ShowEmpByIdComponent {

}
