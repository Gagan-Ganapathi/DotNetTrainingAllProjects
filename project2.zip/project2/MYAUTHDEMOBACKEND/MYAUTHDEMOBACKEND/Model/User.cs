﻿namespace MYAUTHDEMOBACKEND.Model
{
    public class User
    {
        public string EmailId;
        public string Password;
    }
}
