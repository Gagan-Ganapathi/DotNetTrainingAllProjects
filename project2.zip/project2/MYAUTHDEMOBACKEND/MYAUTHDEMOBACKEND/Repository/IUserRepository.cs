﻿using Microsoft.AspNetCore.Mvc;
using MYAUTHDEMOBACKEND.Model;

namespace MYAUTHDEMOBACKEND.Repository
{
    public interface IUserRepository
    {
        public User GetDetails(string email, string password);
        public void postLogin(User user);
    }
}
