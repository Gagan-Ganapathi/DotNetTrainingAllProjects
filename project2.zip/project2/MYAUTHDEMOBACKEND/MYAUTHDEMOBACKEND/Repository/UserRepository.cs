﻿using Microsoft.AspNetCore.Mvc;
using MYAUTHDEMOBACKEND.Model;

namespace MYAUTHDEMOBACKEND.Repository
{
    public class UserRepository : IUserRepository
    {
        public readonly UserDbContext _context;

        public UserRepository(UserDbContext context)
        {
            _context = context;
        }

        public User GetDetails(string email, string password)
        {
            var details = _context.Users.Find(x => x.Email ==email);

            if (password == details.Password) { 



            }
        }

        //public void postLogin(User user)
        //{
        //      _context.Users.Add()  
        //}
    }
}
